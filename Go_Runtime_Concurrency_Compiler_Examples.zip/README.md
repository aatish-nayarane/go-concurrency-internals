# Go Runtime, Concurrency & Compiler Internals — examples

These small files accompany `Go_Runtime_Concurrency_Compiler_Guide.docx`.

## Run
Most examples are standalone programs:
```bash
go run examples/01_goroutines.go
go run -race examples/06_happens_before.go
```

## Compiler diagnostics
```bash
go build -gcflags="-m=2" examples/09_ssa_inlining.go
go build -gcflags="-d=ssa/check_bce/debug=1" examples/10_bounds_check.go
go build -gcflags="-S" examples/11_dead_code.go 2> assembly.txt
```

The exact diagnostic output depends on your installed Go version. `14_pprof_benchmark.go` is a benchmark starter and should be copied into a Go test file named `*_test.go` in a Go module before running `go test -bench`.
