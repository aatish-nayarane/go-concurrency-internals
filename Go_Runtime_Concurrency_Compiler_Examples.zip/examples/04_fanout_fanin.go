package main

import (
	"fmt"
	"sync"
)

func main() {
	jobs := make(chan int)
	results := make(chan int)
	var workers sync.WaitGroup

	for w := 0; w < 3; w++ {
		workers.Add(1)
		go func() {
			defer workers.Done()
			for n := range jobs {
				results <- n * n
			}
		}()
	}

	go func() {
		for n := 1; n <= 5; n++ {
			jobs <- n
		}
		close(jobs)
		workers.Wait()
		close(results)
	}()

	for result := range results {
		fmt.Println(result)
	}
}
