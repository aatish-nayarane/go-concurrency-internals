package main

type VM struct {
	Name   string
	Parent *VM
}

func updateParent(vm, parent *VM) {
	// During concurrent GC, compiler/runtime may use a write barrier here.
	// Do not implement a manual write barrier; Go manages this.
	vm.Parent = parent
}

func main() {
	root := &VM{Name: "root"}
	child := &VM{Name: "child"}
	updateParent(child, root)
}
