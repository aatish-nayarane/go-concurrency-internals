package main

func calculate() int {
	cpu := 4
	ram := 16
	unused := cpu + ram
	_ = unused // Keeps source valid; the calculation has no observable effect.
	return cpu
}

func main() {
	_ = calculate()
}
