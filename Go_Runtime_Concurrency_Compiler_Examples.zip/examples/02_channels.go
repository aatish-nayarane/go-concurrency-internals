package main

import "fmt"

func main() {
	done := make(chan struct{})
	var result int

	go func() {
		result = 42
		close(done)
	}()

	<-done
	fmt.Println(result) // 42; close/receive establishes synchronization.
}
