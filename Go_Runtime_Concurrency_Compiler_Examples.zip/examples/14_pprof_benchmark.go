package example

import "testing"

func add(a, b int) int { return a + b }

func BenchmarkAdd(b *testing.B) {
	for i := 0; i < b.N; i++ {
		_ = add(i, 2)
	}
}

// Example commands:
// go test -bench=. -benchmem
// go test -bench=. -cpuprofile=cpu.out
// go tool pprof cpu.out
// go test -bench=. -memprofile=mem.out
// go tool pprof -alloc_space mem.out
