package main

import (
	"fmt"
	"sync"
)

func main() {
	var wg sync.WaitGroup
	var result int

	wg.Add(1)
	go func() {
		defer wg.Done()
		result = 100
	}()

	wg.Wait()
	fmt.Println(result) // Safe after Wait returns.
}
