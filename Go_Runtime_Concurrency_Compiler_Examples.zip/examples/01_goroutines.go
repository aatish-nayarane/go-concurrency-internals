package main

import (
	"fmt"
	"time"
)

func worker(id int) {
	fmt.Printf("worker %d started\n", id)
	time.Sleep(100 * time.Millisecond)
	fmt.Printf("worker %d finished\n", id)
}

func main() {
	for i := 1; i <= 3; i++ {
		go worker(i)
	}
	time.Sleep(200 * time.Millisecond) // Demonstration only; use synchronization in real code.
}
