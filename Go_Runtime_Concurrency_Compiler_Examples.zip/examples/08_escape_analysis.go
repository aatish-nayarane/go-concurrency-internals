package main

type VM struct {
	Name string
	CPU  int
}

func localVM() VM {
	vm := VM{Name: "test", CPU: 4}
	return vm // Returning by value does not automatically mean heap allocation.
}

func pointerVM() *VM {
	vm := &VM{Name: "test", CPU: 4}
	return vm // This may escape; verify with the compiler.
}

func main() {
	_ = localVM()
	_ = pointerVM()
}
