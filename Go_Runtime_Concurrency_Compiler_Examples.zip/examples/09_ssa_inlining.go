package main

func doubleCPU(cpu int) int {
	return cpu * 2
}

func calculate() int {
	x := 10
	y := 20
	return x + y
}

func main() {
	_ = doubleCPU(8)
	_ = calculate()
}
