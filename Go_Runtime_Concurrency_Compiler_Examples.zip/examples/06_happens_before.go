package main

import "fmt"

func main() {
	done := make(chan struct{})
	var x int

	go func() {
		x = 500
		close(done)
	}()

	<-done
	fmt.Println(x) // 500; synchronized with close(done).
}
