package main

func sum(values []int) int {
	total := 0
	for i := 0; i < len(values); i++ {
		total += values[i]
	}
	return total
}

func first(values []int) int {
	if len(values) == 0 {
		return -1
	}
	return values[0]
}

func main() {
	_ = sum([]int{1, 2, 3})
	_ = first([]int{4, 5})
}
