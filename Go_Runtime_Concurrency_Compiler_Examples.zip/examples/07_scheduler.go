package main

import (
	"fmt"
	"runtime"
	"sync"
)

func main() {
	runtime.GOMAXPROCS(2) // At most two goroutines executing Go code simultaneously.
	var wg sync.WaitGroup

	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			fmt.Println("goroutine", id, "on", runtime.NumGoroutine(), "goroutines total")
		}(i)
	}
	wg.Wait()
}
